#!/usr/bin/env bash
# Run inside the Prefill container: vLLM 0.30.0 + vLLM-Ascend 0.30.0rc2, MRV1, 8 NPUs.
# Example: LOCAL_IP=10.10.0.11 NIC=eth0 MODEL=/models/DeepSeek-V4-Flash-w8a8-mtp bash start_p.sh
set -euo pipefail

# Fixed MRV1 diagnostic baseline; also retain for formal comparisons.
export VLLM_USE_V2_MODEL_RUNNER=0

MODEL="${MODEL:-/models/DeepSeek-V4-Flash-w8a8-mtp}"
NIC="${NIC:-eth0}"
: "${LOCAL_IP:?Set LOCAL_IP to the communication IP of this Prefill machine}"

command -v vllm >/dev/null 2>&1 || { echo "ERROR: vllm is not on PATH" >&2; exit 1; }
[[ -f "$MODEL/config.json" ]] || { echo "ERROR: model config not found: $MODEL/config.json" >&2; exit 1; }
[[ -d "/sys/class/net/$NIC" ]] || { echo "ERROR: network interface not found: $NIC" >&2; exit 1; }

export ASCEND_RT_VISIBLE_DEVICES="${ASCEND_RT_VISIBLE_DEVICES:-0,1,2,3,4,5,6,7}"
export OMP_PROC_BIND=false
export OMP_NUM_THREADS="${OMP_NUM_THREADS:-10}"
export PYTORCH_NPU_ALLOC_CONF="${PYTORCH_NPU_ALLOC_CONF:-expandable_segments:True}"
export HCCL_BUFFSIZE="${HCCL_BUFFSIZE:-1024}"
export TASK_QUEUE_ENABLE=1
export HCCL_OP_EXPANSION_MODE=AIV
export VLLM_RPC_TIMEOUT=3600000
export VLLM_EXECUTE_MODEL_TIMEOUT_SECONDS=30000
export HCCL_EXEC_TIMEOUT=204
export HCCL_CONNECT_TIMEOUT=1200
export HCCL_IF_IP="$LOCAL_IP"
export GLOO_SOCKET_IFNAME="$NIC"
export HCCL_SOCKET_IFNAME="$NIC"
export TP_SOCKET_IFNAME="$NIC"
export NO_PROXY="${NO_PROXY:-},127.0.0.1,localhost,$LOCAL_IP${P_IP:+,$P_IP}${D_IP:+,$D_IP}"
export no_proxy="$NO_PROXY"

if [[ -f /usr/lib/aarch64-linux-gnu/libjemalloc.so.2 ]]; then
  export LD_PRELOAD="/usr/lib/aarch64-linux-gnu/libjemalloc.so.2${LD_PRELOAD:+:$LD_PRELOAD}"
fi

extra=()
if [[ -n "${KV_BYTES:-}" ]]; then
  extra+=(--kv-cache-memory-bytes "$KV_BYTES")
fi

if [[ "${PROFILE:-0}" == 1 ]]; then
  profile_dir="${PROFILE_DIR:-/tmp/pdtest/profiles/prefill}"
  mkdir -p "$profile_dir"
  profile_json=$(python -c 'import json,sys; print(json.dumps(dict(profiler="torch", torch_profiler_dir=sys.argv[1], torch_profiler_with_stack=False)))' "$profile_dir")
  extra+=(--profiler-config "$profile_json")
fi

exec vllm serve "$MODEL" \
  --host 0.0.0.0 \
  --port "${P_PORT:-8100}" \
  --served-model-name "${SERVED_MODEL:-dsv4}" \
  --tensor-parallel-size 8 \
  --data-parallel-size 1 \
  --enable-expert-parallel \
  --max-model-len "${MAX_MODEL_LEN:-133120}" \
  --max-num-seqs "${MAX_SEQS:-32}" \
  --max-num-batched-tokens "${P_TOKEN_BUDGET:-8192}" \
  --gpu-memory-utilization "${MEM_UTIL:-0.90}" \
  --seed 1024 \
  --quantization ascend \
  --tokenizer-mode deepseek_v4 \
  --trust-remote-code \
  --block-size 128 \
  --no-enable-prefix-caching \
  --enable-chunked-prefill \
  --no-disable-hybrid-kv-cache-manager \
  --async-scheduling \
  --safetensors-load-strategy prefetch \
  --enforce-eager \
  --speculative-config '{"method":"mtp","num_speculative_tokens":1,"enforce_eager":true}' \
  --additional-config '{"enable_cpu_binding":true,"enable_dsa_cp":false}' \
  --kv-transfer-config '{"kv_connector":"MooncakeHybridConnector","kv_role":"kv_producer","kv_port":"30000","engine_id":"0","kv_connector_extra_config":{"prefill":{"dp_size":1,"tp_size":8},"decode":{"dp_size":1,"tp_size":8}}}' \
  "${extra[@]}"
